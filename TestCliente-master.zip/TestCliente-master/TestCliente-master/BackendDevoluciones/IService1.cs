﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using System.ServiceModel;

namespace BackendDevoluciones
{
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        List<Devolucion> ListarDevoluciones();

        [OperationContract]
        List<DetalleDevolucion> VerDevolucionDetalle(int idDevolucion);

        [OperationContract]
        List<ProductoDisponible> ConsultarProductosDisponiblesPorVenta(int idVenta);
    }

    [DataContract]
    public class Devolucion
    {
        [DataMember]
        public int IdDevolucion { get; set; }

        [DataMember]
        public int IdVenta { get; set; }

        [DataMember]
        public DateTime FechaDevolucion { get; set; }

        [DataMember]
        public string Motivo { get; set; }

        [DataMember]
        public string Estado { get; set; }
    }

    [DataContract]
    public class DetalleDevolucion
    {
        [DataMember]
        public int IdDevolucion { get; set; }

        [DataMember]
        public int IdVenta { get; set; }

        [DataMember]
        public int IdProducto { get; set; }

        [DataMember]
        public int Cantidad { get; set; }

        [DataMember]
        public string Motivo { get; set; }
    }

    [DataContract]
    public class ProductoDisponible
    {
        [DataMember]
        public int IdProducto { get; set; }

        [DataMember]
        public string Nombre { get; set; }

        [DataMember]
        public int CantidadVendida { get; set; }

        [DataMember]
        public int CantidadDevuelta { get; set; }

        [DataMember]
        public int CantidadDisponible { get; set; }
    }
}