﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace BackendDevoluciones
{
    public class Service1 : IService1
    {
        private string conexion = ConfigurationManager
            .ConnectionStrings["ConexionBD"].ConnectionString;

        // 1. LISTAR DEVOLUCIONES
        public List<Devolucion> ListarDevoluciones()
        {
            List<Devolucion> lista = new List<Devolucion>();

            using (SqlConnection cn = new SqlConnection(conexion))
            {
                string sql = @"SELECT IdDevolucion, IdVenta,
                                      FechaDevolucion, Motivo, Estado
                               FROM Devoluciones
                               ORDER BY FechaDevolucion DESC";

                SqlCommand cmd = new SqlCommand(sql, cn);

                cn.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        Devolucion d = new Devolucion();

                        d.IdDevolucion = Convert.ToInt32(dr["IdDevolucion"]);
                        d.IdVenta = Convert.ToInt32(dr["IdVenta"]);
                        d.FechaDevolucion = Convert.ToDateTime(dr["FechaDevolucion"]);
                        d.Motivo = dr["Motivo"].ToString();
                        d.Estado = dr["Estado"].ToString();

                        lista.Add(d);
                    }
                }
            }

            return lista;
        }

        // 2. VER DETALLE DE DEVOLUCION
        public List<DetalleDevolucion> VerDevolucionDetalle(int idDevolucion)
        {
            List<DetalleDevolucion> lista = new List<DetalleDevolucion>();

            using (SqlConnection cn = new SqlConnection(conexion))
            {
                string sql = @"SELECT d.IdDevolucion,
                                      d.IdVenta,
                                      dd.IdProducto,
                                      dd.Cantidad,
                                      d.Motivo
                               FROM Devoluciones d
                               INNER JOIN DetalleDevolucion dd
                                   ON d.IdDevolucion = dd.IdDevolucion
                               WHERE d.IdDevolucion = @IdDevolucion";

                SqlCommand cmd = new SqlCommand(sql, cn);

                cmd.Parameters.Add("@IdDevolucion", SqlDbType.Int)
                              .Value = idDevolucion;

                cn.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        DetalleDevolucion detalle = new DetalleDevolucion();

                        detalle.IdDevolucion = Convert.ToInt32(dr["IdDevolucion"]);
                        detalle.IdVenta = Convert.ToInt32(dr["IdVenta"]);
                        detalle.IdProducto = Convert.ToInt32(dr["IdProducto"]);
                        detalle.Cantidad = Convert.ToInt32(dr["Cantidad"]);
                        detalle.Motivo = dr["Motivo"].ToString();

                        lista.Add(detalle);
                    }
                }
            }

            return lista;
        }

        // 3. CONSULTAR PRODUCTOS DISPONIBLES POR VENTA
        public List<ProductoDisponible> ConsultarProductosDisponiblesPorVenta(int idVenta)
        {
            List<ProductoDisponible> lista = new List<ProductoDisponible>();

            using (SqlConnection cn = new SqlConnection(conexion))
            {
                string sql = @"
                    SELECT
                        dv.IdProducto,
                        p.Nombre AS Producto,
                        dv.Cantidad AS CantidadVendida,
                        ISNULL(dr.CantidadDevuelta, 0) AS CantidadDevuelta,
                        dv.Cantidad - ISNULL(dr.CantidadDevuelta, 0)
                            AS CantidadDisponible
                    FROM DetalleVenta dv
                    INNER JOIN Productos p
                        ON p.IdProducto = dv.IdProducto
                    LEFT JOIN (
                        SELECT dd.IdProducto,
                               d.IdVenta,
                               SUM(dd.Cantidad) AS CantidadDevuelta
                        FROM DetalleDevolucion dd
                        INNER JOIN Devoluciones d
                            ON d.IdDevolucion = dd.IdDevolucion
                        GROUP BY dd.IdProducto, d.IdVenta
                    ) dr
                        ON dr.IdProducto = dv.IdProducto
                        AND dr.IdVenta = dv.IdVenta
                    WHERE dv.IdVenta = @IdVenta
                      AND dv.Cantidad - ISNULL(dr.CantidadDevuelta, 0) > 0";

                SqlCommand cmd = new SqlCommand(sql, cn);

                cmd.Parameters.Add("@IdVenta", SqlDbType.Int).Value = idVenta;

                cn.Open();

                using (SqlDataReader dr = cmd.ExecuteReader())
                {
                    while (dr.Read())
                    {
                        ProductoDisponible p = new ProductoDisponible();

                        p.IdProducto = Convert.ToInt32(dr["IdProducto"]);
                        p.Nombre = dr["Producto"].ToString();
                        p.CantidadVendida = Convert.ToInt32(dr["CantidadVendida"]);
                        p.CantidadDevuelta = Convert.ToInt32(dr["CantidadDevuelta"]);
                        p.CantidadDisponible = Convert.ToInt32(dr["CantidadDisponible"]);

                        lista.Add(p);
                    }
                }
            }

            return lista;
        }
    }
}